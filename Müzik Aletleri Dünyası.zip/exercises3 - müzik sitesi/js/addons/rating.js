// Rating Initialization
$(document).ready(function() {
    $('#rateMe2').mdbRate();
  });